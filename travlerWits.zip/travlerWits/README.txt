These are the step to get app running 

commands
1.) First install python if you don't already have it

2.) Use pip to install flask 
    sudo pip to install flask 

3.) Create terminal command
    FLASK_APP=server.py

4.) run the server
    flask run 
    








